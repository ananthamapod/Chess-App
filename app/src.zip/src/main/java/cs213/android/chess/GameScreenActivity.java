package cs213.android.chess;

                                                                                                                                                                                                                                                                                                            import android.app.ActionBar;
                                                                                                                                                                                                                                                                                                            import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
                                                                                                                                                                                                                                                                                                            import android.view.ViewGroup;
                                                                                                                                                                                                                                                                                                            import android.view.WindowManager;
                                                                                                                                                                                                                                                                                                            import android.widget.GridLayout;
                                                                                                                                                                                                                                                                                                            import android.widget.GridView;
                                                                                                                                                                                                                                                                                                            import android.widget.ImageButton;
                                                                                                                                                                                                                                                                                                            import android.widget.ImageView;
                                                                                                                                                                                                                                                                                                            import android.widget.RelativeLayout;
                                                                                                                                                                                                                                                                                                            import android.widget.TableLayout;
                                                                                                                                                                                                                                                                                                            import android.widget.TableRow;


public class GameScreenActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_screen);

        View view = findViewById(R.id.board);
        GridView boardView = (GridView) view;
        //createSquares(boardView);
        boardView.setAdapter(new SquareAdapter(this));
    }

    /*private void createSquares(TableLayout board) {
        for(int i = 0; i < 8; i++) {
            TableRow row = new TableRow(this);
            for(int j = 0; j < 8; j++) {
                RelativeLayout square_container = (RelativeLayout) getLayoutInflater().inflate(R.layout.square, null);
                ImageView background = (ImageView) square_container.findViewById(R.id.square_background);
                background.setImageResource(R.drawable.ic_basesquare);

                ImageView foreground = (ImageView) square_container.findViewById(R.id.piece);
                foreground.setImageResource(R.drawable.ic_launcher);

                row.addView(square_container);
            }
            board.addView(row);
        }
    }*/


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement

        return super.onOptionsItemSelected(item);
    }
}
