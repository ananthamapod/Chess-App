package cs213.android.chess;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.util.Log;

/**
 * Created by ananth on 5/2/15.
 */
public class SquareAdapter extends BaseAdapter {
    private Context mContext;
    private int[] images = {R.drawable.ic_basesquare, R.drawable.ic_basesquare2};
    static final String TAG = SquareAdapter.class.getSimpleName();

    public SquareAdapter(Context context) {
        mContext = context;
    }

    @Override
    public int getCount() {
        return 64;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        int parentWidth = parent.getMeasuredWidth();
        int squareWidth = parentWidth/8;
        RelativeLayout squareContainerView;
        if (convertView == null) {
            // if it's not recycled, initialize some attributes
            LayoutInflater layoutInflater = ((Activity)mContext).getLayoutInflater();
            squareContainerView = (RelativeLayout)layoutInflater.inflate(R.layout.square, null);
            ViewGroup.LayoutParams containerParams = squareContainerView.getLayoutParams();
            if(containerParams == null) {
                containerParams = new ViewGroup.LayoutParams(squareWidth, squareWidth);
            }
            containerParams.width = squareWidth;
            containerParams.height = squareWidth;
            squareContainerView.setLayoutParams(containerParams);
            Log.i(TAG, "Position: " + position + ", Square: " + (position + position / 8) % 2);
            Log.i(TAG, "Width" + squareWidth);

            ImageButton background = (ImageButton) squareContainerView.findViewById(R.id.square_background);
            background.setImageResource(images[(position+position/8)%2]);

            ImageView pieceView = (ImageView) squareContainerView.findViewById(R.id.piece);
            pieceView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            pieceView.setPadding(0, 0, 0, 0);
            pieceView.setImageResource(R.drawable.king_w);
            pieceView.setTag(position);
            return squareContainerView;
        }

        return convertView;
    }

    public void updateSquare(int xi, int yi, int xf, int yf) {

    }


}
